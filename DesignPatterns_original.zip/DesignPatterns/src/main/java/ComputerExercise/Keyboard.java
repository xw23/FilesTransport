package ComputerExercise;

public class Keyboard extends ComputerPeripheral{
//@TODO: Implememnt me

    public Keyboard(Computer computer) {
        super(computer);
    }
}
