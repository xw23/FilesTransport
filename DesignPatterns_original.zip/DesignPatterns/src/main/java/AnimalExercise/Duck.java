package AnimalExercise;

public class Duck {
    //@TODO: implement me
}
