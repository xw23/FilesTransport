package AnimalExercise;

public class Cow{
    //@TODO: implement me
}
