package AnimalExercise;

public class AnimalFactory {

    public static Animal create(AnimalType type){
        //@TODO: implement me
        return null;
    }
}
