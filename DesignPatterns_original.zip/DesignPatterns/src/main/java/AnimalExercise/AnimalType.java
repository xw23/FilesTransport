package AnimalExercise;

public enum AnimalType {
    Cat,
    Dog,
    Duck,
    Cow
}
