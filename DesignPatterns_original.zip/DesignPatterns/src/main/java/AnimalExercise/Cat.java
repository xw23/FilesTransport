package AnimalExercise;

public class Cat{
    //@TODO: implement me
}
