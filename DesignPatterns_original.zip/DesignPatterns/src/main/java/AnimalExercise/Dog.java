package AnimalExercise;

public class Dog{
    //@TODO: implement me
}
